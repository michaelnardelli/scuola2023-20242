/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prjuno;

/**
 *
 * @author Michael
 */
public class Prjuno {

    import java.util.Random;

      public static void main(String[] args) {
         //genero il mazzo di carte - serve classe Mazzo.java
         Mazzo mazzo = new Mazzo();
         //mescolo il mazzo - qualcosa tipo mazzo.mescola()
         //leggo n giocatori - uso qua scanner      
         //distribuisco 7 carte agli n giocatori - 
         //stampo le mani dei giocatori
    }

  
}