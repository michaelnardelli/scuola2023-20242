/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prjcaramella;

/**
 *
 * @author Michael
 */
public class Prjcaramella {

 
    public static void main(String[] args) {
        Bustone.apri(); // Apriamo il bustone
        Bustone bustone = new Bustone();

       
        for (int i = 1; i <= 7; i++) {
            bustone.apriBustina(i);
    }}}
    

