I dati generati dal sistema di origine non vengono trasmessi direttamente nella forma in cui sono generati. Il trasmettitore trasforma e codifica i dati in una forma tale da produrre onde o segnali elettromagnetici.


