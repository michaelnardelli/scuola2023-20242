Destinazione riceve i dati in arrivo dal ricevitore.

Destinazione