I dati da trasmettere sono generati da questo dispositivo, esempio: telefoni, personal computer ecc.

