Il ricevitore accetta il segnale dal sistema di trasmissione elo converte in una forma facilmente gestibile dal dispositivo di destinazione.

Ricevitore