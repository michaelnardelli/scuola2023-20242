

Alcuni degli usi più importanti di Internet per gli utenti domestici sono i seguenti:

- Accesso alle informazioni remote
    
- Comunicazione da persona a persona
    
- Intrattenimento interattivo
    
- Commercio elettronico
    


