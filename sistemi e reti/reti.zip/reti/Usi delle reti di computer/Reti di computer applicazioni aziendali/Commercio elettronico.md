Un obiettivo che sta iniziando a diventare più importante nelle aziende è fare affari con i consumatori su Internet. Compagnie aeree, librerie e venditori di musica hanno scoperto che a molti clienti piace la comodità di fare acquisti da casa. Questo settore dovrebbe crescere rapidamente in futuro.

Commercio elettronico: