L'obiettivo è fare tutto programmi, attrezzatura(come stampanti ecc.), esoprattutto dati, disponibile achiunque sulla rete indipendentemente dalla posizione fisica della risorsa e dell'utente.

Condivisione delle risorse: