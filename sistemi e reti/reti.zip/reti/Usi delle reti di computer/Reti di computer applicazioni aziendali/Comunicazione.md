Una rete di computer puòfornire un potente sistema di comunicazione tra i dipendenti. Praticamente ogni azienda che dispone di due o più computer ora dispone della posta elettronica (posta elettronica), che i dipendenti generalmente utilizzano per una grande quantità di comunicazioni quotidiane.

Comunicazione:
