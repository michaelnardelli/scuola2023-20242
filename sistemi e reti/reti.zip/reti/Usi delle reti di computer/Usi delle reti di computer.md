
Cominciamo ad esplorare gli usi delle Reti di Computer con alcuni casi d'uso tradizionali presso le aziende e per i privati ​​per poi passare ai recenti sviluppi nell'area degli utenti mobili e delle reti domestiche.

  


- ## [[Reti di computer applicazioni aziendali]]

- ## [[Reti di computer applicazioni domestiche]]

- ## [[Reti di computer utenti mobili]]
