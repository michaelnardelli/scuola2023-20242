Si riferisce alla progettazione della rete e alla capacità di aumentare o diminuire facilmente il numero di nodi.

##### La scalabilità è la misura della capacità di un sistema di aumentare o diminuire le prestazioni e i costi in risposta ai cambiamenti nelle richieste di elaborazione delle applicazioni e del sistema.

Gli esempi includono le prestazioni di un sistema hardware quando il numero di utenti aumenta, la capacità di un database di resistere a un numero crescente di query

  

Misure di scalabilitàquanto facilmente puoi potenziare o ridimensionare le tue operazioni. Scalabilità di rete significa semplicemente quanto è facile rimuovere o aggiungere larghezza di banda e/o nodi di rete.

Si riferisce alla facilità con cui puoi aumentare la capacità dei tuoi sistemi. Ciò garantirà che tu possa tenere il passo con le crescenti richieste.

La scalabilità della rete è importante per questi motivi:

- La scalabilità della rete garantirà la possibilità di soddisfare le crescenti richieste.
    
- Se stai affrontando una domanda inferiore durante la "bassa stagione", puoi ridimensionare la tua rete per ridurre i costi IT.
    

In parole semplici, la flessibilità IT è molto importante. Se la tua rete è flessibile, puoi facilmente soddisfare le tue richieste di risorse. Questo ti aiuterà a controllare i costi ed evitare interruzioni del servizio.
