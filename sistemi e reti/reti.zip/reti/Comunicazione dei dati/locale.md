La comunicazione locale avviene quandoi dispositivi comunicanti si trovano nella stessa area geografica, stesso edificio, o faccia a faccia ecc.

locale