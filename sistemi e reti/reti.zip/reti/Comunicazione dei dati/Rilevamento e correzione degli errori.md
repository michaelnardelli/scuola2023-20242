

Questo argomento riguarda due discipline diverse:

- Sistemi e Reti (rilevazione e correzione degli errori di trasmissione)
    
- TPSIT (codici per la rilevazione e correzione di errori all’interno del Bus di sistema, nella comunicazione fra e con periferiche, nella trasmissione in senso lato).
    

I metodi e i codici sono gli stessi, quindi li tratteremo solo in Sistemi e Reti.

  

Riferimenti:

1. Internetworking, Unità 5, Lezione 4 (pagg. 215 - 224)
    
2. Testo TPSIT, Unità 2, Lezione 3 (pagg. 140 - 154)
    

Potete tenere come base il primo, ma vi chiedo di studiare anche gli approfondimenti e soprattutto i molti esempi del secondo.


