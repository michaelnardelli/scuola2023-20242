Viene chiamato lo scambio di dati tra due dispositivi attraverso un mezzo di trasmissione Comunicazione dei dati. I dati vengono scambiati sotto forma di 0 e 1. Il mezzo di trasmissione utilizzato è il cavo o le onde elettromagnetiche. Perché avvenga la comunicazione dei dati, il dispositivo di comunicazione deve far parte di un sistema di comunicazione. La comunicazione dati ha due tipi: [[locale]] e [[Comunicazione dati remota]], discussi di seguito:


### Componenti della comunicazione dei dati

1. Messaggio: È l'informazione da consegnare.
    
2. Mittente: Il mittente è la persona che invia il messaggio.
    
3. Ricevitore: Il destinatario è la persona a cui viene inviato il messaggio.
    
4. medio: È il mezzo attraverso il quale viene inviato il messaggio.
    
5. Protocolli ([[Sistemi aperti - Protocolli e standard]])Protocollo: Queste sono alcune regole che regolano la comunicazione dei dati.
    

## Controllo del flusso  
Internetworking, Unità 5, Lezione 5

Pagg. 225 - 228

Vedi anche: Classroom, slide nel materiale 5.2 - Il controllo di flusso.

- ### [[Il protocollo della finestra scorrevole]]
- ## [[Rilevamento e correzione degli errori]]
- 

  


  
  

