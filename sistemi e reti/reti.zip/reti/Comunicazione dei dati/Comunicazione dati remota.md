La comunicazione remota avviene a distanza cioè i dispositivi sono più lontani. L'efficacia di una comunicazione di dati può essere misurata attraverso le seguenti caratteristiche:

1. Consegna: La consegna deve essere effettuata alla destinazione corretta.
    
2. Tempestività: La consegna dovrebbe essere puntuale.
    
3. Precisione: I dati forniti devono essere accurati.
    

remoto