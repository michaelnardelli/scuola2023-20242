- Elevato costo di installazione: Sebbene la LAN ridurrà i costi nel tempo grazie alle risorse del computer condivise, i costi iniziali di configurazione dell'installazione delle reti locali sono elevati.
    
- Violazioni della privacy: ILL'amministratore LAN ha i diritti per controllare i file di dati personali di ogni singolo utente LAN.Inoltre può controllare la cronologia di Internet e la cronologia dell'utilizzo del computer dell'utente della LAN.
    
- Minaccia alla sicurezza dei dati: Gli utenti non autorizzati possono accedere a dati importanti di un'organizzazione se il repository di dati centralizzato non è protetto adeguatamente dall'amministratore della LAN.
    
- Lavoro di manutenzione LAN: La rete locale richiede un amministratore LAN perché ci sono problemi di installazioni software o guasti hardware o disturbi dei cavi nella rete locale. Per questo lavoro a tempo pieno è necessario un amministratore LAN.
    
- Copre un'area limitata: La rete locale copre una piccola area come un ufficio, un edificio o un gruppo di edifici vicini.
    