Uno dei computer in una rete può diventare unserverservire tutti i restanti computer chiamaticlienti. Il software può essere memorizzato sul server e può essere utilizzato dai restanti client.
    
- Connettere localmente tutte le postazioni di lavoro in un edificio per lasciarlicomunicare tra loro a livello locale senza alcun accesso a Internet.
    
- Condivisione di risorse comuni come le stampanti ecc. sono alcune applicazioni comuni della LAN.

Applicazioni di LAN