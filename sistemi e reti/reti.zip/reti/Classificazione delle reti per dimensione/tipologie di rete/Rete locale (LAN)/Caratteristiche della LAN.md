- Le LAN sono reti private, non soggetto a tariffe o altri controlli normativi.
    
- Le LAN funzionano a velocità relativamente elevate rispetto alla tipica WAN.
    
- Esistono diversi tipi di metodi di controllo dell'accesso ai media in una LAN, i più importanti sono Ethernet, Token ring.
    
- Essocollega i computer in un unico edificio, blocco o campus, cioè lavorano in aarea geografica ristretta.

### Caratteristiche della LAN